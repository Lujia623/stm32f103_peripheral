# MQTT 协议文档合集 v1.0

整理日期：2026-10-27

本合集包含两部分：

1. **官方规范原文**：MQTT 3.1、MQTT 3.1.1（含 Plus Errata 01）、MQTT 5.0、MQTT-SN 1.2。
2. **整理版手册**：一册中文的《MQTT 协议全版本手册》，把字段、位域、合法取值、必填条件、报文流程和版本差异整理成可查的表，并配有逐字节示例与测试清单。

> 整理版是学习与实现参考，不是 OASIS / IBM 的官方规范，也不是逐字翻译。协议冲突时，以 `01_官方规范原文` 中的原文为准。

## 先看哪一份

| 需求 | 建议打开 |
|---|---|
| 阅读、打印、做笔记 | `02_整理版/MQTT协议全版本手册_整理版_v1.0.pdf`（85 页，带 PDF 书签） |
| 在 Word 中编辑 | `02_整理版/MQTT协议全版本手册_整理版_v1.0.docx` |
| 在浏览器中阅读 / 全文搜索 | `02_整理版/MQTT协议全版本手册_整理版_v1.0.html`（图片已内嵌，单文件） |
| 核对原文、引用条款 | `01_官方规范原文/` 下对应 PDF/HTML |
| 校验文件完整性 | `03_校验与来源/SHA256SUMS.txt` |

## 目录结构

```text
交付_MQTT协议文档/
├─ README.md
├─ 01_官方规范原文/
│  ├─ MQTT_v3.1_IBM_2010.html
│  ├─ MQTT_v3.1.1_OS_2014-10-29.pdf
│  ├─ MQTT_v3.1.1_Plus_Errata01_2015-12-10.pdf
│  ├─ MQTT_v3.1.1_Errata01_2015-12-10.pdf
│  ├─ MQTT_v3.1.1_OS_2014-10-29.html
│  ├─ MQTT_v5.0_OS_2019-03-07.pdf
│  ├─ MQTT_v5.0_OS_2019-03-07.html
│  └─ MQTT-SN_v1.2_2013-11-14.pdf
├─ 02_整理版/
│  ├─ MQTT协议全版本手册_整理版_v1.0.pdf
│  ├─ MQTT协议全版本手册_整理版_v1.0.docx
│  └─ MQTT协议全版本手册_整理版_v1.0.html
└─ 03_校验与来源/
   ├─ SHA256SUMS.txt
   └─ 来源与版本说明.md
```

## 整理版包含什么

- **版本速查**：3.1 / 3.1.1 / 5.0 / MQTT-SN 1.2 的定位、协议标识、传输与关键限制。
- **基础机制**：发布/订阅模型、报文三段式结构、Remaining Length、数据类型、UTF-8、主题与通配符、QoS 0/1/2、会话、Keep Alive、Will、保留消息。
- **MQTT 3.1.1**：14 类报文的字段表、固定头 Flags、CONNACK 返回码、SUBACK 返回码、ClientId/标志位/Packet ID/重发/错误处理。
- **MQTT 5.0**：27 个标准属性、全量原因码、15 类报文、Clean Start + Session Expiry、Will Delay、Topic Alias、Receive Maximum、请求/响应、共享订阅、AUTH、能力协商。
- **MQTT-SN 1.2**：26 类消息、Length 的 1/3 字节编码、Flags 位域、Topic ID/预定义 Topic/短主题名、网关发现、注册、发布、订阅、睡眠客户端、重传与定时器。
- **对照与落地**：四版本 CONNECT/能力/报文映射、3.1.1 → 5.0 迁移清单、逐字节示例、客户端/Broker 检查表、一致性测试矩阵、抓包排错。

## 版本与日期

| 规范 | 版本 / 日期 | 本地文件 |
|---|---|---|
| MQTT 3.1 | 2010，IBM / Eurotech | `MQTT_v3.1_IBM_2010.html` |
| MQTT 3.1.1 | OASIS Standard，2014-10-29 | `MQTT_v3.1.1_OS_2014-10-29.pdf` / `.html` |
| MQTT 3.1.1 Plus Errata 01 | OASIS Standard + Approved Errata 01，2015-12-10 | `MQTT_v3.1.1_Plus_Errata01_2015-12-10.pdf` |
| MQTT 3.1.1 Errata 01（仅勘误清单） | OASIS Approved Errata，2015-12-10 | `MQTT_v3.1.1_Errata01_2015-12-10.pdf` |
| MQTT 5.0 | OASIS Standard，2019-03-07 | `MQTT_v5.0_OS_2019-03-07.pdf` / `.html` |
| MQTT-SN 1.2 | IBM，2013-11-14 | `MQTT-SN_v1.2_2013-11-14.pdf` |

说明：

- “MQTT 3.1.1 Plus Errata 01”不是新的协议版本，协议级别仍是 **4**；它是把已批准勘误合并进全文的版本。
- MQTT 3.1 的官方发布形式是 HTML，本合集保留原始 HTML，未做格式转换。
- MQTT-SN 1.2 不是 OASIS Standard。OASIS 的 MQTT-SN 2.0 仍在标准化过程中，本合集未纳入草案。
- 截至本合集整理时，MQTT 5.0（2019-03-07）仍是当前 OASIS Standard。

## 校验

在 `交付_MQTT协议文档` 目录下执行：

Windows PowerShell：

```powershell
Get-FileHash .\02_整理版\MQTT协议全版本手册_整理版_v1.0.pdf -Algorithm SHA256
```

Linux / macOS：

```bash
sha256sum -c 03_校验与来源/SHA256SUMS.txt
```

`SHA256SUMS.txt` 使用“哈希 + 两个空格 + 相对路径”的格式；哈希为小写十六进制。

## 重要说明

- 官方规范的版权归 OASIS / IBM 各自的权利人所有；随附文件保留了原始版权声明与许可文本，仅用于学习、实现参考与归档。
- 整理版手册是独立整理与解读，不替代官方规范，也不构成 OASIS 或 IBM 的官方译本。
- 涉及认证、合规、法律用途时，请引用官方原文的版本、日期与章节号。
- PDF 由 HTML 经无头 Chrome 打印生成；DOCX 由 python-docx 生成。两者内容一致，但分页/字体可能略有差异，视觉以 PDF 为准。
- MQTT-SN 1.2 的官方委员会下载页在本次网络环境中连接超时，实际文件取自 OASIS 官方 GitHub 组织仓库的镜像；来源与哈希见 `03_校验与来源/来源与版本说明.md`。
